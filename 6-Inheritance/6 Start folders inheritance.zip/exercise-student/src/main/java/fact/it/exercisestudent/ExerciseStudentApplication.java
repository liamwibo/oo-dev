package fact.it.exercisestudent;

import fact.it.exercisestudent.model.DormStudent;
import fact.it.exercisestudent.model.Student;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseStudentApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExerciseStudentApplication.class, args);
        //write your code here

        System.exit(0);

    }

}
