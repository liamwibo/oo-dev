package fact.it.exerciselesson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseLessonApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExerciseLessonApplication.class, args);

        System.exit(0);
    }

}
