package fact.it.exercisesupplier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseSupplierApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExerciseSupplierApplication.class, args);


        System.exit(0);
    }

}
